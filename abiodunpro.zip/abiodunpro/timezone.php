<?php
date_default_timezone_set("Africa/Lagos");
$time = time();
$timezone = strftime("%b-%d-%Y %H:%M:%S",$time);
$timezone;


?>